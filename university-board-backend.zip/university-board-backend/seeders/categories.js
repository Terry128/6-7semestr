const { Category } = require('../models');

const defaultCategories = [
    { name: 'Учеба и репетиторство', slug: 'study-and-tutoring' },
    { name: 'Работа и стажировки', slug: 'jobs-and-internships' },
    { name: 'Жилье и общежитие', slug: 'housing-and-dormitory' },
    { name: 'Купля-продажа', slug: 'buy-and-sell' },
    { name: 'Мероприятия и события', slug: 'events' },
    { name: 'Бюро находок', slug: 'lost-and-found' },
    { name: 'Наука и проекты', slug: 'science-and-projects' },
    { name: 'Учебный процесс', slug: 'academic-process' },
];

async function seedCategories() {
    const count = await Category.count();
    if (count === 0) {
        await Category.bulkCreate(defaultCategories);
        console.log('✅ Категории успешно созданы (seed)');
    } else {
        console.log('ℹ️  Категории уже существуют, seed пропущен');
    }
}

module.exports = seedCategories;