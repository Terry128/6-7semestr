const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');
const authMiddleware = require('../middleware/auth');

// Публичные роуты
router.post('/setup-admin', authController.setupAdmin);
router.post('/register', authController.register);
router.post('/login', authController.login);

// Защищенный роут (требует валидный JWT в заголовке Authorization: Bearer <token>)
router.get('/me', authMiddleware, authController.getMe);

module.exports = router;