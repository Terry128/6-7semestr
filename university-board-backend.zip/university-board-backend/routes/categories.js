const express = require('express');
const router = express.Router();
const categoryController = require('../controllers/categoryController');

// Публичный роут для получения списка категорий
router.get('/', categoryController.getAllCategories);

module.exports = router;