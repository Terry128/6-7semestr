const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');
const authMiddleware = require('../middleware/auth');
const roleCheck = require('../middleware/roleCheck');

// Все роуты — только для админа
router.use(authMiddleware);
router.use(roleCheck('admin'));

router.get('/', userController.getAllUsers);
router.patch('/:id/role', userController.changeUserRole);
router.patch('/:id/ban', userController.toggleBanUser);

module.exports = router;