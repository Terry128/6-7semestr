const express = require('express');
const router = express.Router();
const announcementController = require('../controllers/announcementController');
const authMiddleware = require('../middleware/auth');
const roleCheck = require('../middleware/roleCheck');

// Публичный роут (только одобренные)
router.get('/', announcementController.getAllAnnouncements);

// Защищенные роуты
router.post('/', authMiddleware, announcementController.createAnnouncement);
// Роут для админа — получить все объявления на модерации
router.get('/pending', authMiddleware, roleCheck('admin'), announcementController.getPendingAnnouncements);


router.get('/my', authMiddleware, announcementController.getMyAnnouncements);
router.delete('/:id', authMiddleware, announcementController.deleteAnnouncement);

// Роут только для админа
router.patch('/:id/moderate', authMiddleware, roleCheck('admin'), announcementController.moderateAnnouncement);

module.exports = router;