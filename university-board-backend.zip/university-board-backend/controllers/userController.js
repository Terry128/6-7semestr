const bcrypt = require('bcrypt');
const { User } = require('../models');

// 1. Получить всех пользователей (только для админа)
exports.getAllUsers = async (req, res) => {
    try {
        const users = await User.findAll({
            attributes: { exclude: ['password'] }, // Не возвращаем хэши паролей
            order: [['createdAt', 'DESC']]
        });
        res.json(users);
    } catch (error) {
        res.status(500).json({ message: 'Ошибка сервера', error: error.message });
    }
};

// 2. Сменить роль пользователя (только для админа)
exports.changeUserRole = async (req, res) => {
    try {
        const { id } = req.params;
        const { role } = req.body;

        // Валидация роли
        if (!['student', 'teacher', 'admin'].includes(role)) {
            return res.status(400).json({ message: 'Недопустимая роль' });
        }

        const user = await User.findByPk(id);
        if (!user) {
            return res.status(404).json({ message: 'Пользователь не найден' });
        }

        // Нельзя сменить роль самому себе (защита от случайной блокировки)
        if (user.id === req.user.id) {
            return res.status(400).json({ message: 'Вы не можете изменить свою собственную роль' });
        }

        user.role = role;
        await user.save();

        res.json({
            message: `Роль пользователя изменена на "${role}"`,
            user: {
                id: user.id,
                email: user.email,
                role: user.role,
                firstName: user.firstName,
                lastName: user.lastName
            }
        });
    } catch (error) {
        res.status(500).json({ message: 'Ошибка сервера', error: error.message });
    }
};

// 3. Заблокировать/разблокировать пользователя (только для админа)
exports.toggleBanUser = async (req, res) => {
    try {
        const { id } = req.params;

        const user = await User.findByPk(id);
        if (!user) {
            return res.status(404).json({ message: 'Пользователь не найден' });
        }

        // Нельзя заблокировать самого себя
        if (user.id === req.user.id) {
            return res.status(400).json({ message: 'Вы не можете заблокировать самого себя' });
        }

        user.isBanned = !user.isBanned;
        await user.save();

        res.json({
            message: user.isBanned
                ? 'Пользователь заблокирован'
                : 'Пользователь разблокирован',
            user: {
                id: user.id,
                email: user.email,
                isBanned: user.isBanned
            }
        });
    } catch (error) {
        res.status(500).json({ message: 'Ошибка сервера', error: error.message });
    }
};
