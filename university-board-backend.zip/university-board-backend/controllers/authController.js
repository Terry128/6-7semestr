const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { User } = require('../models');

// 1. Создание ПЕРВОГО администратора (незащищенный роут, но с защитой от повторного вызова)
exports.setupAdmin = async (req, res) => {
    try {
        const userCount = await User.count();
        if (userCount > 0) {
            return res.status(403).json({ message: 'Первичная настройка уже завершена. Администратор уже существует.' });
        }

        const { email, password, firstName, lastName, patronymic } = req.body;
        if (!email || !password || !firstName || !lastName) {
            return res.status(400).json({ message: 'Email, пароль, имя и фамилия обязательны' });
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        const admin = await User.create({
            email,
            password: hashedPassword,
            firstName,
            lastName,
            patronymic: patronymic || null,
            role: 'admin'
        });

        res.status(201).json({
            message: 'Первый администратор успешно создан',
            user: { id: admin.id, email: admin.email, role: admin.role }
        });
    } catch (error) {
        res.status(500).json({ message: 'Ошибка сервера', error: error.message });
    }
};

// 2. Регистрация нового пользователя
// ВАЖНО: если это ПЕРВЫЙ пользователь в системе — он автоматически становится админом
exports.register = async (req, res) => {
    try {
        const { email, password, firstName, lastName, patronymic } = req.body;
        if (!email || !password || !firstName || !lastName) {
            return res.status(400).json({ message: 'Email, пароль, имя и фамилия обязательны' });
        }

        const existingUser = await User.findOne({ where: { email } });
        if (existingUser) {
            return res.status(400).json({ message: 'Пользователь с таким email уже существует' });
        }

        // 🔥 КЛЮЧЕВАЯ ЛОГИКА: определяем роль
        const userCount = await User.count();
        const isFirstUser = userCount === 0;
        const assignedRole = isFirstUser ? 'admin' : 'student';

        const hashedPassword = await bcrypt.hash(password, 10);
        const user = await User.create({
            email,
            password: hashedPassword,
            firstName,
            lastName,
            patronymic: patronymic || null,
            role: assignedRole
        });

        res.status(201).json({
            message: isFirstUser
                ? 'Регистрация успешна! Вы стали первым администратором системы.'
                : 'Регистрация успешна',
            user: {
                id: user.id,
                email: user.email,
                role: user.role
            }
        });
    } catch (error) {
        res.status(500).json({ message: 'Ошибка сервера', error: error.message });
    }
};

// 3. Вход в систему (Login)
exports.login = async (req, res) => {
    try {
        const { email, password } = req.body;
        if (!email || !password) {
            return res.status(400).json({ message: 'Email и пароль обязательны' });
        }

        const user = await User.findOne({ where: { email } });
        if (!user) {
            return res.status(400).json({ message: 'Неверный email или пароль' });
        }

        if (user.isBanned) {
            return res.status(403).json({ message: 'Ваш аккаунт заблокирован администрацией' });
        }

        const isPasswordValid = await bcrypt.compare(password, user.password);
        if (!isPasswordValid) {
            return res.status(400).json({ message: 'Неверный email или пароль' });
        }

        // Генерация JWT токена
        const token = jwt.sign(
            { id: user.id, email: user.email, role: user.role },
            process.env.JWT_SECRET,
            { expiresIn: '7d' } // Токен живет 7 дней
        );

        res.json({
            message: 'Вход выполнен успешно',
            token,
            user: {
                id: user.id,
                email: user.email,
                role: user.role,
                firstName: user.firstName,
                lastName: user.lastName
            }
        });
    } catch (error) {
        res.status(500).json({ message: 'Ошибка сервера', error: error.message });
    }
};

// 4. Получение данных текущего авторизованного пользователя
exports.getMe = async (req, res) => {
    try {
        // req.user уже добавлен middleware auth.js
        const user = await User.findByPk(req.user.id, {
            attributes: { exclude: ['password'] } // Не возвращаем хэш пароля
        });
        res.json(user);
    } catch (error) {
        res.status(500).json({ message: 'Ошибка сервера', error: error.message });
    }
};
