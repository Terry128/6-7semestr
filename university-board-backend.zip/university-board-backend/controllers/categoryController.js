const { Category } = require('../models');

// Получить все категории (публичный роут)
exports.getAllCategories = async (req, res) => {
    try {
        const categories = await Category.findAll({
            order: [['id', 'ASC']]
        });
        res.json(categories);
    } catch (error) {
        res.status(500).json({ message: 'Ошибка сервера', error: error.message });
    }
};