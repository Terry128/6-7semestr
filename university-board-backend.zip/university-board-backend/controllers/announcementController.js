const { Announcement, Category, User } = require('../models');

// 1. Создание объявления (доступно авторизованным пользователям)
exports.createAnnouncement = async (req, res) => {
    try {
        const { title, content, categoryId } = req.body;

        if (!title || !content || !categoryId) {
            return res.status(400).json({ message: 'Заголовок, содержание и категория обязательны' });
        }

        // Принудительно ставим статус 'pending' для модерации
        const announcement = await Announcement.create({
            title,
            content,
            categoryId,
            authorId: req.user.id,
            status: 'pending'
        });

        res.status(201).json({
            message: 'Объявление создано и отправлено на модерацию',
            announcement
        });
    } catch (error) {
        // Обработка ошибки неверного categoryId (нарушение внешнего ключа)
        if (error.name === 'SequelizeForeignKeyConstraintError') {
            return res.status(400).json({ message: 'Указанная категория не существует' });
        }
        res.status(500).json({ message: 'Ошибка сервера', error: error.message });
    }
};

// 2. Получение списка одобренных объявлений (публичный роут)
exports.getAllAnnouncements = async (req, res) => {
    try {
        const { page = 1, limit = 10, categoryId } = req.query;
        const offset = (page - 1) * limit;

        const whereClause = { status: 'approved' };
        if (categoryId) {
            whereClause.categoryId = categoryId;
        }

        const { count, rows } = await Announcement.findAndCountAll({
            where: whereClause,
            include: [
                {
                    model: User,
                    as: 'author',
                    attributes: ['id', 'firstName', 'lastName', 'role'] // Не возвращаем email и пароль
                },
                {
                    model: Category,
                    as: 'categoryData',
                    attributes: ['id', 'name', 'slug']
                }
            ],
            order: [['createdAt', 'DESC']],
            limit: parseInt(limit),
            offset: parseInt(offset)
        });

        res.json({
            totalItems: count,
            totalPages: Math.ceil(count / limit),
            currentPage: parseInt(page),
            announcements: rows
        });
    } catch (error) {
        res.status(500).json({ message: 'Ошибка сервера', error: error.message });
    }
};

// 3. Получение моих объявлений (любой статус, только для автора)
exports.getMyAnnouncements = async (req, res) => {
    try {
        const announcements = await Announcement.findAll({
            where: { authorId: req.user.id },
            include: [
                { model: Category, as: 'categoryData', attributes: ['name'] }
            ],
            order: [['createdAt', 'DESC']]
        });
        res.json(announcements);
    } catch (error) {
        res.status(500).json({ message: 'Ошибка сервера', error: error.message });
    }
};

// 4. Модерация объявления (только для админа)
exports.moderateAnnouncement = async (req, res) => {
    try {
        const { id } = req.params;
        const { status } = req.body;

        if (!['approved', 'rejected'].includes(status)) {
            return res.status(400).json({ message: 'Статус должен быть "approved" или "rejected"' });
        }

        const announcement = await Announcement.findByPk(id);
        if (!announcement) {
            return res.status(404).json({ message: 'Объявление не найдено' });
        }

        announcement.status = status;
        await announcement.save();

        res.json({
            message: `Объявление успешно ${status === 'approved' ? 'одобрено' : 'отклонено'}`,
            announcement
        });
    } catch (error) {
        res.status(500).json({ message: 'Ошибка сервера', error: error.message });
    }
};

// 5. Удаление объявления (автор или админ)
exports.deleteAnnouncement = async (req, res) => {
    try {
        const { id } = req.params;
        const announcement = await Announcement.findByPk(id);

        if (!announcement) {
            return res.status(404).json({ message: 'Объявление не найдено' });
        }

        // Проверка прав: админ или автор
        if (req.user.role !== 'admin' && announcement.authorId !== req.user.id) {
            return res.status(403).json({ message: 'У вас нет прав на удаление этого объявления' });
        }

        await announcement.destroy();
        res.json({ message: 'Объявление успешно удалено' });
    } catch (error) {
        res.status(500).json({ message: 'Ошибка сервера', error: error.message });
    }
};

// 6. Получить все объявления на модерации (только для админа)
exports.getPendingAnnouncements = async (req, res) => {
    try {
        const announcements = await Announcement.findAll({
            where: { status: 'pending' },
            include: [
                {
                    model: User,
                    as: 'author',
                    attributes: ['id', 'firstName', 'lastName', 'email', 'role']
                },
                {
                    model: Category,
                    as: 'categoryData',
                    attributes: ['id', 'name']
                }
            ],
            order: [['createdAt', 'ASC']] // Сначала самые старые
        });
        res.json(announcements);
    } catch (error) {
        res.status(500).json({ message: 'Ошибка сервера', error: error.message });
    }
};
