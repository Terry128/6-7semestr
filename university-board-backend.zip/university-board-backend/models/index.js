const sequelize = require('../config/database');
const User = require('./User');
const Category = require('./Category');
const Announcement = require('./Announcement');

// --- Ассоциации (Связи между таблицами) ---

// Пользователь может иметь много объявлений
User.hasMany(Announcement, {
    foreignKey: 'authorId',
    as: 'author'
});
Announcement.belongsTo(User, {
    foreignKey: 'authorId',
    as: 'author'
});

// Категория может содержать много объявлений
Category.hasMany(Announcement, {
    foreignKey: 'categoryId',
    as: 'categoryData'
});
Announcement.belongsTo(Category, {
    foreignKey: 'categoryId',
    as: 'categoryData'
});

module.exports = {
    sequelize,
    User,
    Category,
    Announcement,
};