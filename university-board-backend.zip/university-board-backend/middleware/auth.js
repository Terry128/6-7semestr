const jwt = require('jsonwebtoken');
const { User } = require('../models');

module.exports = async (req, res, next) => {
    try {
        const authHeader = req.headers.authorization;
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return res.status(401).json({ message: 'Необходима авторизация (отсутствует токен)' });
        }

        const token = authHeader.split(' ')[1];
        const decoded = jwt.verify(token, process.env.JWT_SECRET);

        const user = await User.findByPk(decoded.id);
        if (!user || user.isBanned) {
            return res.status(401).json({ message: 'Пользователь не найден или заблокирован' });
        }

        req.user = user; // Добавляем пользователя в объект запроса
        next();
    } catch (error) {
        return res.status(401).json({ message: 'Неверный или просроченный токен' });
    }
};